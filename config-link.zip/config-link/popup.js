﻿chrome.browserAction.setBadgeText({text: 'New'});
chrome.browserAction.setBadgeBackgroundColor({color: [255, 0, 0, 255]});

