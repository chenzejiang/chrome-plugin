const app = {
	state: [
		{
			"name": "pc-门店管理系统",
			"data": [
				{
					"type": "alpha",
					"name": "内测",
					"link": "http://192.168.1.206/ssms-pc/#/",
					"username": "17700000001",
					"password": "123456"
				},
				{
					"type": "abtest",
					"name": "公测",
					"link": "http://test-cms.carisok.com/#/",
					"username": "17375833921",
					"password": "123456"
				},
				{
					"type": "alpha",
					"name": "灰度",
					"link": "http://abtest-cms.carisok.com/#/",
					"username": "14733330004",
					"password": "654321"
				},
				{
					"type": "release",
					"name": "正式",
					"link": "http://cms.carisok.com/#/",
					"username": "",
					"password": ""
				}
			]
		}
	],
	/**
	 * 渲染Dom
	 */
	appendDom() {
		let data = this.state;

		const btnBox = (_data) => {
			return _data.map((item) => {
				let _str = `<li><a data-href="${item.link}" href="javascript:void(0);">${item.name}</a></li>`
				return _str;
			});
		}

		const projectBoxDom = data.map((item) => {
			let _str = `
			<div class="projectBox">
				<h2>${item.name}</h2>
				<ul>
					${btnBox(item.data)}
				</ul>
			</div>`;
			return _str;
		});
		console.log(projectBoxDom);
		$("#container").append(projectBoxDom);
	},
	/**
	 * 绑定DOM事件
	 */
	bindDomEvent() {
		const that = this;
		$("#container").on('click','a',function(){
			that.openUrl($(this).attr('data-href'));
	  	});
	},
	/**
	 * 打开资源
	 * @param {string} _url 
	 */
	openUrl(_url) {
		chrome.tabs.create({url: _url});
	},
	/**
	 * 初始化
	 */
	init() {
		this.bindDomEvent();
		this.appendDom();
	}
}
$(function(){
	app.init();
});