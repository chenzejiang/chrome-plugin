﻿const app = {
	state: [
		{
			"name": "pc-门店管理系统",
			"data": [
				{
					"type": "alpha",
					"name": "内测",
					"link": "http://192.168.1.206/ssms-pc/#/",
					"username": "17700000001",
					"password": "123456"
				}
			]
		}
	],
	/**
	 * 渲染Dom
	 */
	appendDom() {
		let data = this.state;

		const btnBox = (_data) => {
			return _data.map((item) => {
				let _str = `<li><a data-href="${item.link}" href="javascript:void(0);">${item.name}</a></li>`
				return _str;
			});
		}

		const projectBoxDom = data.map((item) => {
			let _str = `
			<div class="projectBox">
				<h2>${item.name}</h2>
				<ul>
					${btnBox(item.data)}
				</ul>
			</div>`;
			return _str;
		});
		console.log(projectBoxDom);
		$("#container").append(projectBoxDom);
	},
	/**
	 * 绑定DOM事件
	 */
	bindDomEvent() {
		const that = this;
		$("#save").on('click', function(){
			console.log(12333);
	  	});
	},
	/**
	 * 打开资源
	 * @param {string} _url 
	 */
	openUrl(_url) {
		chrome.tabs.create({url: _url});
	},
	/**
	 * 初始化
	 */
	init() {
		$('#save').click(function () {
			console.log(12312312);
		});
		console.log(1123);
		// this.bindDomEvent();
		// this.appendDom();
	}
}
// $(function(){
// 	app.init();
// });


// document.addEventListener('DOMContentLoaded', function() {
// 	var defaultConfig = {color: 'white', showImage: true}; // 默认配置
// 	// 读取数据，第一个参数是指定要读取的key以及设置默认值
// 	chrome.storage.sync.get(defaultConfig, function(items) {
// 		document.getElementById('color').value = items.color;
// 		document.getElementById('show_image').checked = items.showImage;
// 	});
// });

document.getElementById('save').addEventListener('click', function() {
	// var configLink = document.getElementById('textarea').value;
	console.log(123);
	// document.getElementById('status').textContent = '保存成功！';
	// 这里貌似会存在刷新不及时的问题
	// chrome.extension.getBackgroundPage().showImage = showImage; // 让background即使生效
	// chrome.storage.sync.set({showImage: showImage}, function() {
	// 	// 注意新版的options页面alert不生效！
	// 	// alert('保存成功！');
	// 	document.getElementById('status').textContent = '保存成功！';
	// 	setTimeout(() => {document.getElementById('status').textContent = '';}, 800);
	// });
});