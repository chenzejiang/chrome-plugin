﻿(function() {
	console.log('这是 simple-chrome-plugin-demo 的content-script！');
})();